import oqp

def ints_1e(mol):
    """Compute a set of one-electron integrals"""
    oqp.int1e(mol)
