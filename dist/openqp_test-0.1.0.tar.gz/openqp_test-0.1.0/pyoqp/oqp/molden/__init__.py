"""
Molden compatibility module
"""
